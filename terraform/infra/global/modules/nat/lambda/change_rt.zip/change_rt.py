import boto3
import os
from botocore.exceptions import ClientError

ec2 = boto3.client('ec2')

ROUTE_TABLE_A_ID = os.environ.get('ROUTE_TABLE_A_ID')
ROUTE_TABLE_B_ID = os.environ.get('ROUTE_TABLE_B_ID')
SUBNET_A_ID = os.environ.get('SUBNET_A_ID')
SUBNET_B_ID = os.environ.get('SUBNET_B_ID')

def lambda_handler(event, context):
    instance_id = event.get('detail', {}).get('instance-id')
    state = event.get('detail', {}).get('state')

    if not instance_id or state != 'running':
        print(f"Ignorando evento: instance_id={instance_id}, state={state}")
        return

    print(f"Procesando nueva instancia: {instance_id}")

    response = ec2.describe_instances(InstanceIds=[instance_id])
    instance = response['Reservations'][0]['Instances'][0]

    subnet_id = instance.get('SubnetId')
    eni_id = instance.get('NetworkInterfaces')[0]['NetworkInterfaceId']

    if subnet_id == SUBNET_A_ID:
        route_table_id = ROUTE_TABLE_A_ID
    elif subnet_id == SUBNET_B_ID:
        route_table_id = ROUTE_TABLE_B_ID
    else:
        print(f"Subnet {subnet_id} no coincide con las configuradas, ignorando.")
        return

    print(f"Actualizando ruta 0.0.0.0/0 en {route_table_id} → ENI {eni_id}")

    try:
        ec2.replace_route(
            RouteTableId=route_table_id,
            DestinationCidrBlock='0.0.0.0/0',
            NetworkInterfaceId=eni_id
        )
        print("Ruta reemplazada exitosamente")

    except ClientError as e:
        if "InvalidParameterValue" in str(e):
            print("La ruta no existía, creando nueva ruta...")
            ec2.create_route(
                RouteTableId=route_table_id,
                DestinationCidrBlock='0.0.0.0/0',
                NetworkInterfaceId=eni_id
            )
            print("Ruta creada exitosamente")
        else:
            raise
