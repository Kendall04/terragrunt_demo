import boto3, os
ec2 = boto3.client('ec2')

SUBNET_A_ID = os.environ.get('SUBNET_A_ID')
SUBNET_B_ID = os.environ.get('SUBNET_B_ID')
EIP_A_ALLOCATION_ID = os.environ.get('EIP_A_ALLOCATION_ID')
EIP_B_ALLOCATION_ID = os.environ.get('EIP_B_ALLOCATION_ID')

def lambda_handler(event, context):
    instance_id = event.get('detail', {}).get('instance-id')
    state = event.get('detail', {}).get('state')
    if not instance_id or state != 'running':
        print(f"Ignorando evento: instance_id={instance_id}, state={state}")
        return

    r = ec2.describe_instances(InstanceIds=[instance_id])
    inst = r['Reservations'][0]['Instances'][0]
    subnet_id = inst.get('SubnetId')
    eni_id = inst['NetworkInterfaces'][0]['NetworkInterfaceId']

    if subnet_id == SUBNET_A_ID:
        alloc = EIP_A_ALLOCATION_ID
    elif subnet_id == SUBNET_B_ID:
        alloc = EIP_B_ALLOCATION_ID
    else:
        print(f"Subnet {subnet_id} no coincide con A/B")
        return

    print(f"Asociando EIP {alloc} a ENI {eni_id}")
    ec2.associate_address(AllocationId=alloc, NetworkInterfaceId=eni_id, AllowReassociation=True)
    print("OK")
