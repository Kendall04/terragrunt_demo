import boto3, os, time
ec2 = boto3.client('ec2')
ASG_NAMES = [s.strip() for s in os.environ.get('ASG_NAMES','').split(',') if s.strip()]

def lambda_handler(event, context):
    detail = event.get('detail', {})
    iid = detail.get('instance-id')
    state = detail.get('state')
    if not iid or state != 'running':
        print(f"Ignorando evento: iid={iid}, state={state}")
        return

    asg_name = get_asg_tag(iid) or (time.sleep(5) or get_asg_tag(iid))
    if ASG_NAMES and asg_name not in ASG_NAMES:
        print(f"IID {iid} no autorizado (asg={asg_name})")
        return

    ec2.modify_instance_attribute(InstanceId=iid, SourceDestCheck={'Value': False})
    print(f"Source/Dest Check desactivado en {iid}")

def get_asg_tag(iid):
    try:
        r = ec2.describe_instances(InstanceIds=[iid])
        tags = r['Reservations'][0]['Instances'][0].get('Tags', [])
        return next((t['Value'] for t in tags if t['Key']=='aws:autoscaling:groupName'), None)
    except Exception as e:
        print(f"Error obteniendo tags: {e}")
        return None
